<?php
   session_start();
   ob_start();
?>
<!-- this website was built for gaining experience in coding, nothing on this website is real (everything is demo)
Date it was built - 20-11-2021
By - Mirian Kurtanidze 
-->
<?php 
   $server = "localhost";
   $username = "root";
   $password = "";
   $dbname = "cafe";
   
   
   $connection = mysqli_connect($server, $username, $password, $dbname);
   if(!$connection) {
       echo "something went wrong" . mysqli_error($connection);
   }
   
   
   ?>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <title>Kალაქური</title>
      <meta http-equiv="X-UA-Compatible" content="IE=Edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="keywords" content="">
      <meta name="description" content="">
      <link rel="icon" href="https://i.ibb.co/b5FN3rh/Khinkali-icon-Linear-logo-of-georgian-dumplings-Meat-filling-wrapped-in-cone-shaped-dough-Black-simp.jpg">
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css/animate.min.css">
      <link rel="stylesheet" href="css/font-awesome.min.css">
      <link rel="stylesheet" href="css/nivo-lightbox.css">
      <link rel="stylesheet" href="css/nivo_themes/default/default.css">
      <link rel="stylesheet" href="css/style.css">
      <link href='https://fonts.googleapis.com/css?family=Roboto:400,500' rel='stylesheet' type='text/css'>
   </head>
   <body>
      <!-- preloader section -->
      <section class="preloader">
         <div class="sk-spinner sk-spinner-pulse"></div>
      </section>
      <!-- navigation section -->
      <section class="navbar navbar-default navbar-fixed-top" role="navigation">
         <div class="container">
            <div class="navbar-header">
               <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
               <span class="icon icon-bar"></span>
               <span class="icon icon-bar"></span>
               <span class="icon icon-bar"></span>
               </button>
               <a href="#" class="navbar-brand">Kალაქური</a>
            </div>
            <div class="collapse navbar-collapse">
               <ul class="nav navbar-nav navbar-right">
                  <li><a href="#home" class="smoothScroll">მთავარი</a></li>
                  <li><a href="#gallery" class="smoothScroll">პირველი მენიუ</a></li>
                  <li><a href="#menu" class="smoothScroll">მთავარი მენიუ</a></li>
                  <li><a href="#team" class="smoothScroll">შეფ-მზარეულები</a></li>
                  <li><a href="#contact" class="smoothScroll">კონტაქტი</a></li>
               </ul>
            </div>
         </div>
      </section>
      <!-- home section -->
      <section id="home" class="parallax-section">
      <div class="bg-image"></div>
         <div class="container" style="vertical-align: middle; display: flex; justify-content: center; align-items: center;">
            <div class="row">
               <div class="col-md-12 col-sm-12">
                  <h1 style="font-size:17px;">24/7 უფასო მიტანის სერვისი</h1>
                  <h2 style="font-size:50px; color:white; background-color:#1a1a1a;" > რესტორანი Kალაქური</h2>
                  <a href="#gallery" class="smoothScroll btn btn-default">ნახე პროდუქცია</a>
               </div>
         </div>
         </div>
      </section>
      <section id="gallery" class="parallax-section">
         <div class="container">
            <div class="row">
               <div class="col-md-offset-2 col-md-8 col-sm-12 text-center">
                  <h1 class="heading">გალერია</h1>
                  <hr>
               </div>
               <?php
                  $query="select * FROM mainmenu";
                  $result= mysqli_query($connection, $query);
                  while($results = mysqli_fetch_array($result)){
                  	$picture = $results['picture'];
                  echo '
                  			<div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.3s" style="max-width:500px;">
                  			
                  				<a href="'.$picture.'" data-lightbox-gallery="zenda-gallery"><img src="'.$picture.'" alt="gallery img"  style="width:300px; height:260px;"></a>
                  				<div>
                  					<h2>'.$results['name'].'</h2>
                  					<span>'.$results['des'].'</span>
                  				</div>
                  				</div>
                  ';
                  }
                  ?>
            </div>
         </div>
         </div>
      </section>
      <!-- menu section -->
      <section id="menu" class="parallax-section">
         <div class="container">
            <div class="row">
               <div class="col-md-offset-2 col-md-8 col-sm-12 text-center">
                  <h1 class="heading">მთავარი მენიუ</h1>
                  <hr>
               </div>
               <!-- <div class="col-md-6 col-sm-6">
                  <h4>Lemon-Rosemary Vegetable ................ <span>$20.50</span></h4>
                  <h5>Chicken / Rosemary / Lemon</h5>
                  </div> -->
               <?php
                  $query="select * FROM specialmenu";
                  $result= mysqli_query($connection, $query);
                  while($results_two = mysqli_fetch_array($result)){
                  	$picture = $results['price'];
                  echo '
                  <div class="col-md-6 col-sm-6">
                  <h4>'.$results_two['name'].' ................ <span>₾'.$results_two['price'].'</span></h4>
                  <h5>'.$results_two['descr'].'</h5>
                  </div>
                  
                  ';
                  }
                  ?>
            </div>
         </div>
      </section>
      <!-- team section -->
      <section id="team" class="parallax-section">
         <div class="container">
            <div class="row">
               <div class="col-md-offset-2 col-md-8 col-sm-12 text-center">
                  <h1 class="heading">Kალაქურის მზარეულები</h1>
                  <hr>
               </div>
               <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.3s">
                  <img src="https://scontent.ftbs3-1.fna.fbcdn.net/v/t1.6435-9/p526x296/119962807_3054145314831209_2433507723543328160_n.jpg?_nc_cat=104&ccb=1-5&_nc_sid=8bfeb9&_nc_ohc=4llwl5L_GcwAX8YFEx3&_nc_ht=scontent.ftbs3-1.fna&oh=7733c783fa4ed2f3fb9df84970e80bb6&oe=61BD1918" style="width:300px; height:400px;" class="img-responsive center-block" style="width:400px;" alt="team img">
                  <h2>ლუკა ნაჭყეპია</h4>
                  <h3>დამხმარე შეფი</h3>
               </div>
               <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
                  <img src="https://cdn.ambebi.ge/media/images/2018/sxvadasxva/tedelurikonstantine_2019-05-17_cO86iVtg2bl25Y7.jpg" style="width:300px;" class="img-responsive center-block" style="width:400px;  height:400px;" alt="team img">
                  <h2>კონსტანტინე თედელური</h4>
                  <h3>მთავარი მზარეული</h3>
               </div>
               <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.9s">
                  <img src="https://scontent.ftbs3-2.fna.fbcdn.net/v/t1.6435-9/p526x296/119829677_633361993883811_5428015854233168442_n.jpg?_nc_cat=107&ccb=1-5&_nc_sid=730e14&_nc_ohc=nEBGWYEtJx8AX9AI38c&_nc_ht=scontent.ftbs3-2.fna&oh=5a758e12fe5a4533fc3eaa685ad8e507&oe=61BC68F1" class="img-responsive center-block" style="width:400px;" alt="team img" style="width:300px;  height:400px;">
                  <h2>ლევან კობიაშვილი</h4>
                  <h3>კრიტიკოსი</h3>
               </div>
            </div>
         </div>
      </section>


      <!-- inserting data from contact form (client side -> db) to our table called 'contact-us' -->
      <?php
         if(isset($_POST['submit']) && $_POST['name'] !== '' && $_POST['email'] !== '' & $_POST['message'] !== ''){
         $name = htmlspecialchars($_POST['name']);
         $email = $_POST['email'];
         $message = $_POST['message'];
         $sql = $connection->prepare("INSERT INTO `contactus` (`name`, `email`, `message`) VALUES (?, ?, ?);");
         $sql->bind_param("sss", $name, $email, $message);
         $sql->execute();
         echo "succesfully added to db";
         $sql->close();
         header("Location: index.php");
         }
         ?>



      <!-- contact section -->
      <section id="contact" class="parallax-section">
         <div class="container">
            <div class="row">
               <div class="col-md-offset-1 col-md-10 col-sm-12 text-center">
                  <h1 class="heading">კონტაქტი</h1>
                  <hr>
               </div>
               <div class="col-md-offset-1 col-md-10 col-sm-12 wow fadeIn" data-wow-delay="0.9s">
                  <form action="#" method="post">
                     <div class="col-md-6 col-sm-6">
                        <input name="name" type="text" maxlength="15" class="form-control" id="name" placeholder="სახელი">
                     </div>
                     <div class="col-md-6 col-sm-6">
                        <input name="email" type="email" maxlength="35" class="form-control" id="email" placeholder="ელ-ფოსტა">
                     </div>
                     <div class="col-md-12 col-sm-12">
                        <textarea name="message" type="text" rows="8"maxlength="500" class="form-control" id="message" placeholder="წერილი"></textarea>
                     </div>
                     <div class="col-md-offset-3 col-md-6 col-sm-offset-3 col-sm-6">
                        <input name="submit" type="submit" class="form-control" id="submit" value="გაგზავნა">
                     </div>
                  </form>
               </div>
               <div class="col-md-2 col-sm-1"></div>
            </div>
         </div>
      </section>
      <!-- footer section -->
      <footer class="parallax-section">
         <div class="container kitchen">
            <div class="row">
               <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
                  <h2 class="heading">კონტაქტი</h2>
                  <div class="ph">
                     <p><i class="fa fa-phone"></i>ტელეფონი</p>
                     <h4>+995 555 00 00 00</h4>
                  </div>
                  <div class="address">
                     <p><i class="fa fa-map-marker"></i>ადგილმდებარეობა</p>
                     <h4>თბილისი, აღმაშენებლის გამზირი N23</h4>
                  </div>
               </div>
               <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
                  <h2 class="heading">ღია საათები</h2>
                  <p>კვირა<span>10:30სთ - 22:00სთ </span></p>
                  <p>ორ-ხუთ<span>9:00სთ - 20:00სთ </span></p>
                  <p>პარასკევი<span>11:30სთ - 22:00სთ</span></p>
               </div>
            </div>
         </div>
      </footer>
      <!-- copyright section -->
      <section id="copyright">
         <div class="container">
            <div class="row">
               <div class="col-md-12 col-sm-12">
                  <h2>Kალაქური</h2>
                  <p>ყველა უფლება დაცულია ©
                     | 2021
                  </p>
               </div>
            </div>
         </div>
      </section>
      <!-- JAVASCRIPT JS FILES -->	
      <script src="js/jquery.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="js/jquery.parallax.js"></script>
      <script src="js/smoothscroll.js"></script>
      <script src="js/nivo-lightbox.min.js"></script>
      <script src="js/wow.min.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html>