<link rel="icon" href="https://i.ibb.co/b5FN3rh/Khinkali-icon-Linear-logo-of-georgian-dumplings-Meat-filling-wrapped-in-cone-shaped-dough-Black-simp.jpg">
<?php
//connection to database

$server = "localhost";
$username = "root";
$password = "";
$dbname = "cafe";


$connection = mysqli_connect($server, $username, $password, $dbname);
if(!$connection) {
    echo "something went wrong" . mysqli_error($connection);
}
?>

<?php
// checking if there is login button pressed to take the credentials and check it
if(isset($_POST['submit']) && $_POST['username'] !== '' && $_POST['password'] !== '' && strlen($_POST['username']) < 10 && strlen($_POST['password']) < 10){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $stmt = $connection->prepare("SELECT username, password FROM admin WHERE username=? AND password=?");
    $stmt->bind_param('ss', $username, $password);
    $stmt->execute();
    $stmt->bind_result($username, $password);
    $stmt->store_result();
    if($stmt->num_rows > 0){
        session_start();
        $one_random = substr(md5(mt_rand()), 0, 10);
        $_SESSION['double_check'] = "$one_random";
        $sql = "UPDATE `session` SET `session` = '$one_random' WHERE `session`.`id` = 1;";
        $onsert = mysqli_query($connection, $sql);
        $random = substr(md5(mt_rand()), 0, 70);
        echo "<script>alert($random)</script>";
        $sql = "UPDATE `token` SET `token` = '$random' WHERE `token`.`id` = 1;";
        $insert = mysqli_query($connection, $sql);
        $sql = "UPDATE `token` SET date=now();";
        $insert = mysqli_query($connection, $sql);
        header("Location: admin.php?tk=$random"); 
        exit();
    }
    else {
        sleep(1);
        header("Location: login.php");
    
    }
}



?>
<meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>შესვლა ადმინ პანელში</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
<br><br><br><br>
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet"> 
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-2"></div>
            <div class="col-lg-6 col-md-8 login-box">
   <br>   <br>
   <br>

                <div class="col-lg-12 login-title">
                    ადმინ პანელი
                </div>

                <div class="col-lg-12 login-form">
                    <div class="col-lg-12 login-form">
                        <form action="" method="post">
                            <div class="form-group">
                                <label class="form-control-label">სახელი</label>
                                <input type="text" name="username" maxlength="10" class="form-control">
                            </div>
                            <div class="form-group">
                                <label class="form-control-label">პაროლი</label>
                                <input type="password" name="password" maxlength="10" class="form-control" i>
                            </div>

                            <div class="col-lg-12 loginbttm">
                                <div class="col-lg-6 login-btm login-text">
                                    <!-- Error Message -->
                                </div>
                                <div class="col-lg-6 login-btm login-button">
                                    <button type="submit" name="submit" class="btn btn-outline-primary">შესვლა</button><br>
                                    
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-3 col-md-2"></div>
            </div>
        </div>

<style>
body {
    font-family: 'Roboto', sans-serif;
    background-image: url('https://st4.depositphotos.com/3878845/24598/v/950/depositphotos_245985264-stock-illustration-khinkali-georgian-traditional-food-seamless.jpg');
}

.login-box {
    margin-top: 75px;
    height: 399px;
    background: #f0f0f3;
    text-align: center;
}

.login-key {
    height: 100px;
    font-size: 80px;
    line-height: 100px;
    background: -webkit-linear-gradient(#27EF9F, #0DB8DE);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.login-title {
    margin-top: 15px;
    text-align: center;
    font-size: 30px;
    letter-spacing: 2px;
    margin-top: 15px;
    font-weight: bold;
}

.login-form {
    margin-top: 25px;
    text-align: left;
}

input[type=text] {
    border: none;
    border-top: 0px;
    border-radius: 0px;
    font-weight: bold;
    outline: 0;
    margin-bottom: 20px;
    padding-left: 0px;
    color: black;
}

input[type=password] {
    border: none;
    border-top: 0px;
    border-radius: 0px;
    font-weight: bold;
    outline: 0;
    padding-left: 0px;
    margin-bottom: 20px;
    color: black;
}

.form-group {
    margin-bottom: 40px;
    outline: 0px;
}

.form-control:focus {
    border-color: inherit;
    -webkit-box-shadow: none;
    box-shadow: none;
    border-bottom: 2px solid #0DB8DE;
    outline: 0;
    color: black;
}

input:focus {
    outline: none;
    box-shadow: 0 0 0;
}

label {
    margin-bottom: 0px;
}

.form-control-label {
    font-size: 10px;
    color: #6C6C6C;
    font-weight: bold;
    letter-spacing: 1px;
}

.btn-outline-primary {
    color: #0DB8DE;
    font-weight: bold;
    letter-spacing: 1px;
}

.btn-outline-primary:hover {
    background-color: #0DB8DE;
    right: 0px;
}

.login-btm {
    float: left;
}

.login-button {
    padding-right: 0px;
    text-align: right;
    margin-bottom: 25px;
}

.login-text {
    text-align: left;
    padding-left: 0px;
    color: #A2A4A4;
}

.loginbttm {
    padding: 0px;
}
</style>


