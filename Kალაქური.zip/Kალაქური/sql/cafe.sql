-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2021 at 12:57 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cafe`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(1) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'root', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `id` int(100) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `message` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `mainmenu`
--

CREATE TABLE `mainmenu` (
  `id` int(11) NOT NULL,
  `picture` varchar(700) NOT NULL,
  `name` varchar(300) NOT NULL,
  `des` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mainmenu`
--

INSERT INTO `mainmenu` (`id`, `picture`, `name`, `des`) VALUES
(10, 'https://www.saveur.com/uploads/2018/11/20/VW6J76DATFDQVDRX5YV55WOXME-1024x767.jpg?auto=webp', 'ხაჭაპური (გურული)', 'ხაჭაპური საქართველოს თითქმის ყველა ქართულ რესტორანში შეხვდებით, ის ტრადიციული და ამავე დროს არაჩვეულებრივი გემოს მატარებელი კერძია რომელიც ყველისა და გამომცხვარი ცომისგან შედგება'),
(11, 'https://farm1.staticflickr.com/14/14102008_d1364e1a7a.jpg', 'მწვადი', 'ქართული მწვადი, ნაკვერჩხალის სიმხურვალეზე შებრაწული საქონლის ხორცი გარნირით (ხახვით)'),
(12, 'http://vinoge.com/files/image/chakapuli.jpg', 'ჩაქაფული', 'ჩაქაფული ასევე ტრადიციული ქართული კერძია რომელიც ზემო იმერეთიდან მოდის. ძირითადად ცხვრის ან ბატკნის ხორცისგან მზადდება და წვენთან მწვანილთან ერთად მისართმევია'),
(14, 'https://cdn-ajllj.nitrocdn.com/weeEmxgjxuZdyBHoFCSrvizvoqeHXtDf/assets/static/optimized/rev-c479a22/wp-content/uploads/2020/10/best-khinkali-restaurants-tbilisi.jpg', 'ხინკალი ქალაქური', 'ხინკალი საქართველოს ტრადიციული კერძია, რესტორან Kალაქურში თქვენ მის უამრავ სახეობას შეხვდებით');

-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE `session` (
  `id` int(1) NOT NULL,
  `session` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `session`
--

INSERT INTO `session` (`id`, `session`) VALUES
(1, '5d73bbccad');

-- --------------------------------------------------------

--
-- Table structure for table `specialmenu`
--

CREATE TABLE `specialmenu` (
  `id` int(100) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `price` float NOT NULL,
  `descr` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `specialmenu`
--

INSERT INTO `specialmenu` (`id`, `name`, `price`, `descr`) VALUES
(25, 'ხინკალი ქალაქური', 1, 'ხინკალი ქალაქური, ხორცი და ცომი მოხარშული'),
(38, 'აჭარული ხაჭაპური', 13, 'აჭარული ხაჭაპური დამზადებული ყველისა და კვერცხის მიქსტურისგან, განსხვავებული სხვა დანარჩენი ტიპის ხაჭაპურებისგან'),
(39, 'ჩაქაფული', 15, 'კაი გემრიელი ჩაქაფული');

-- --------------------------------------------------------

--
-- Table structure for table `token`
--

CREATE TABLE `token` (
  `date` date NOT NULL DEFAULT current_timestamp(),
  `id` int(1) NOT NULL,
  `token` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `token`
--

INSERT INTO `token` (`date`, `id`, `token`) VALUES
('2021-11-20', 1, '4c4c09aca735826863a2bd3e862f77c3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mainmenu`
--
ALTER TABLE `mainmenu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `session`
--
ALTER TABLE `session`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `specialmenu`
--
ALTER TABLE `specialmenu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `token`
--
ALTER TABLE `token`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `mainmenu`
--
ALTER TABLE `mainmenu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `session`
--
ALTER TABLE `session`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `specialmenu`
--
ALTER TABLE `specialmenu`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `token`
--
ALTER TABLE `token`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
