<style>
   *{
  margin: 0;
  padding: 0;
}

</style>
<!-- Demo website built just for an experience -->
<!-- Note from Mirian -->



<html lang="en">
   <head>
      <meta charset="utf-8">
      <title>Kალაქური</title>
      <meta http-equiv="X-UA-Compatible" content="IE=Edge">
      <link rel="icon" href="https://i.ibb.co/b5FN3rh/Khinkali-icon-Linear-logo-of-georgian-dumplings-Meat-filling-wrapped-in-cone-shaped-dough-Black-simp.jpg">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="keywords" content="">
      <meta name="description" content="">
      <?php
         // we connect to external files - CSS - JS
      ?>
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css/animate.min.css">
      <link rel="stylesheet" href="css/font-awesome.min.css">
      <link rel="stylesheet" href="css/nivo-lightbox.css">
      <link rel="stylesheet" href="css/nivo_themes/default/default.css">
      <link rel="stylesheet" href="css/style.css">
      <link href='https://fonts.googleapis.com/css?family=Roboto:400,500' rel='stylesheet' type='text/css'>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   </head>
   <body style="overflow-x: hidden; background-image: url('https://st4.depositphotos.com/3878845/24598/v/950/depositphotos_245985264-stock-illustration-khinkali-georgian-traditional-food-seamless.jpg');">

      <?php
      error_reporting(E_ALL);
      ini_set('display_errors', 1);
         //connection to database
         
         $server = "localhost";
         $username = "root";
         $password = "";
         $dbname = "cafe";
         
         
         $connection = mysqli_connect($server, $username, $password, $dbname);
         if(!$connection) {
             echo "something went wrong" . mysqli_error($connection);
         }
         ?>
      <?php
         //basically here we start the session for later use
         session_start();
         //then we get the value of that session variable called "double_check" which we created before now on login page
         $session = $_SESSION["double_check"];
         //we get the value of superglobal variable called "tk"
         $tk = $_GET['tk'];
         //here we write sql code in order to get information from the database
         $sql = "select * from token where token = '$tk'";  
         //here we submit the code to sql database
         $result = mysqli_query($connection, $sql);
         //here we return bool, wheter or not superglobal and token in database matches  
         $count = mysqli_num_rows($result); // this is gonna find out how many rows is being matched with information we provided to database ($tk - token we provided from superglobal $_GET)
         
         
         //here we check the session stored on our local computer and then compare it to one stored in database
         $sqll = "select * from session where id = 1";
         //we send the request to db in order to execute this command
         $resultt= mysqli_query($connection, $sqll);
         //we fetch the data from db
         while($results = mysqli_fetch_array($resultt)){
         //if statement to check wheter or not this is both return TRUE
         if($count && $_SESSION["double_check"] == $results['session']){
            
             
            // here we add product to table called specialmenu with input forms located under products list
            if(isset($_POST['submit']) && $_POST['name'] !== '' && $_POST['desc'] !== '' && $_POST['price'] !== ''){
               $name = $_POST['name'];
               $price = $_POST['price'];
               $desc = $_POST['desc'];
               // prepared statement to prevent sql injection basically
               $stmt = $connection->prepare("INSERT INTO specialmenu (name, price, descr) VALUES (?, ?, ?)");
               $stmt->bind_param("sds", $name, $price, $desc);
               $stmt->execute();
               header("Location: admin.php?tk=$tk"); 
               $stmt->close();
            }
               // here we add product to table called specialmenu with input forms located under products list
               //
               // P.S HAVE NO IDEA WHAT IS THE REASON OF THIS ERROR BUT I GUESS THERE's A PROBLEM ON 83 LINE
               //
               // Please don't leave this code Mirian, you gotta finish the work
               if(isset($_POST['submit_one']) && $_POST['name_one'] !== '' && $_POST['desc_one'] !== '' && $_POST['image_one'] !== ''){
               $name = $_POST['name_one'];
               $image = $_POST['image_one'];
               $desc = $_POST['desc_one'];
               // prepared statement to prevent sql injection basically
               $stmt = $connection->prepare("INSERT INTO mainmenu (picture, name, des) VALUES (?, ?, ?)");
               echo $connection->error;
               $stmt->bind_param("sss", $image, $name, $desc);
               $stmt->execute();
               echo $connection->error;
               header("Location: admin.php?tk=$tk"); 
               $stmt->close();
               echo $connection->error;
            }
   

            ?>
            <script>

               // here we trigger the function once delete button is pressed for the first part of meals (with no pics)
            function delete_product(clicked_id){
               window.location = 'delete.php?delete_id=' + clicked_id;
            };
              // here we trigger the function once delete button is pressed for the second part of meals (with pics)
            function delete_product_two(clicked_id_two){
               window.location = 'deletetwo.php?delete_id=' + clicked_id_two;
            };

            </script>

             <!-- Here We start the menu -->
             <!-- Here We start the menu -->
             <!-- Here We start the menu -->
             <!-- Here We start the menu -->

            <div class="parent">
              <h1 class=''>რესტორანი Kალაქური</h1><br><br>
            <div class="first">

            <!-- here we start the first child -->
            <!-- here we start the first child -->
            <!-- here we start the first child -->
            <!-- here we start the first child -->
            <!-- here we start the first child -->

            <div class="container">
                        <div class="row" style="display: inline-block;">
                           <div class="col-md-offset-0 col-md-4 col-sm-4">
                              <h1 class="heading" style="margin-left:30px;">მთავარი მენიუ</h1>
                              <hr>
                           </div>
                           
                     <?php
                     $query="select * FROM specialmenu";
                     $result= mysqli_query($connection, $query);
                     
                     while($results_two = mysqli_fetch_array($result)){
                        // here is list of products, as u can see I included one delete button per product, after it's pressed function reply_click is gonna be triggered and gonna redirect to delete.php with get parameter delete_id set to id of button pressed
                     echo '
                     <div class="col-md-9 col-sm-9" style="display: inline-block;">
                     <nobr><h3 >'.$results_two['name'].' ................ <span>₾'.$results_two['price'].'</span></h3></nobr>
                      
                     <h4><div><h4 style="">'.$results_two['descr'].'</h4> </div> <button type="button" onClick="delete_product(this.id)" class="btn btn-danger" id="'.$results_two['id'].'" style=" height:30px;">წაშლა</button><button type="button" class="btn btn-warning" id = "'.$results_two['id'].'" style="height:30px; margin-left:3px;"  disabled onClick="edit_product(this.id)">შესწორება</button> </h4>
                     </div>
                     
                     ';
                     }
                     // we add a product basically
                     echo '
                     <br>
                     <br>
                     <div class="col-md-9 col-sm-9" style="margin-top:30px;">
                     <h3>დაამატე პროდუქტი</h3>
                     <form method="POST" action="">
                     <nobr> <input type="text" class="form-control" id="name" placeholder="პროდუქტის დასახელება" name="name" style="width:300px;display: inline-block;"> <h3 style="display:inline">‏‏‎ ‎‏‏‎................ ‎‏‏‎</h3><input type="number" class="form-control" id="price" name="price" placeholder="ფასი" style="width:70px;display: inline-block;"></nobr> <br>
                     <input type="text" class="form-control" id="desc" placeholder="აღწერილობა" name="desc" style="width:200px; margin-top:10px; display:inline;"> <button type="submit" name="submit" class="btn btn-success" style="height:33px; margin-left:3px; display:inline">Add</button>
                     </div>
                     </form>
                     '
                     ?>

            <!-- here we end the first child -->
            <!-- here we end the first child -->
            <!-- here we end the first child -->
            <!-- here we end the first child -->


            </div>
            <div class="second">
            <!-- here we do the second child (gallery) -->
            <!-- here we do the second child (gallery) -->
            <!-- here we do the second child (gallery) -->
            <!-- here we do the second child (gallery) -->

            <?php
                     $query="select * FROM mainmenu";
                     $result= mysqli_query($connection, $query);
                     echo '
                     <br>
                     <div class="row" style="display: inline-block;">
                     <div class="col-md-offset-0 col-md-4 col-sm-4">
                        <h1 class="heading" style="margin-left:30px;">გალერია</h1>
                        <hr style="width:160px;">
                     </div>
                     ';
                     while($results_two = mysqli_fetch_array($result)){
                        // here is list of products, as u can see I included one delete button per product, after it's pressed function reply_click is gonna be triggered and gonna redirect to delete.php with get parameter delete_id set to id of button pressed
                     echo '
                     <div class="col-md-9 col-sm-9">
                     
                     <nobr><h3 >'.$results_two['name'].' ................ <img src="'.$results_two['picture'].'" style="width:60px; height:50px;"></h3></nobr>
                     <h4><h4>'.$results_two['des'].'</h4>  <button type="button" id = "'.$results_two['id'].'" onClick="delete_product_two(this.id)" class="btn btn-danger" style=" height:30px;">წაშლა</button><button type="button" class="btn btn-warning" style="height:30px; margin-left:3px;" disabled onClick="edit_product(this.id)">შესწორება</button> </h4>
                     </div>
                     
                     ';
                     }
                     // we add a product basically
                     echo '
                     <br>
                     <br>
                     <br>
                     <div class="col-md-9 col-sm-9" style="margin-top:30px;">
                     <h3>დაამატე პროდუქტი</h3>
                     <form method="POST" action="">
                     <nobr><input type="text" class="form-control" id="name" placeholder="პროდუქტის დასახელება" name="name_one" style="width:300px;display: inline-block;"> <h3 style="display:inline">‏‏‎ ‎‏‏‎................ ‎‏‏‎</h3><input type="text" class="form-control" id="image" name="image_one" placeholder="სურათის ლინკი" style="width:150px;display: inline-block;"> <br>
                     </nobr>
                     <input type="text" class="form-control" id="desc" placeholder="აღწერილობა" name="desc_one" style="width:200px; margin-top:10px; display:inline;"> <button type="submit" name="submit_one" class="btn btn-success" style="height:33px; margin-left:3px; display:inline">დამატება</button>
                     </div>
                     </form>
                     '
                     ?>

           </div>
              </div>
            <!-- here we end the second child (gallery) -->
            <!-- here we end the second child (gallery) -->
            <!-- here we end the second child (gallery) -->
            <!-- here we end the second child (gallery) -->
            <!-- here we end the second child (gallery) -->
            <!-- here we end the second child (gallery) -->


              <br>
            <!-- HERE ENDS THE MENU -->
          
<?php
// here we redirect to the login page if credentials don't match or error happens
         }
         else {
            header("Location: login.php");
         }
                  }