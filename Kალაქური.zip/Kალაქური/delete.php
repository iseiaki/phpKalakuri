<?php
         //connection to database
         
         $server = "localhost";
         $username = "root";
         $password = "";
         $dbname = "cafe";
         
         
         $connection = mysqli_connect($server, $username, $password, $dbname);
         if(!$connection) {
             echo "something went wrong" . mysqli_error($connection);
         }


        session_start();
        $session = $_SESSION["double_check"];
        $sqll = "select * from session where id = 1";
        //we send the request to db in order to execute this command
        $resultt= mysqli_query($connection, $sqll);
        //we fetch the data from db
        while($results = mysqli_fetch_array($resultt)){
        if($_SESSION["double_check"] == $results['session']){
        //here goes the code if we succeed

        $id = $_GET['delete_id'];
        echo $id;

       $sql = "DELETE FROM `specialmenu` WHERE `specialmenu`.`id` = $id";
       $result = mysqli_query($connection, $sql);
       if(!$result){
           echo "error!";
       } 
       
       else {
           header('Location: ' . $_SERVER['HTTP_REFERER']);
       }


        }
    else {
        header("Location: index.php"); 
    }
    
    }

         ?>
  